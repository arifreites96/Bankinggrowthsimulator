#include "investmentcalculator.h"

// Constructor
InvestmentCalculator::InvestmentCalculator(double initial, double monthly, double interest, int numYears) {
    initialInvestment = initial;
    monthlyDeposit = monthly;
    annualInterest = interest;
    years = numYears;
}

// Helper function: calculates and prints balances
void InvestmentCalculator::CalculateBalance(bool includeMonthlyDeposit) const {
    double balance = initialInvestment;
    double monthlyInterestRate = (annualInterest / 100.0) / 12.0;

    cout << fixed << setprecision(2);
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
    cout << "---------------------------------------------------" << endl;

    for (int year = 1; year <= years; ++year) {
        double interestEarned = 0.0;

        for (int month = 0; month < 12; ++month) {
            if (includeMonthlyDeposit) {
                balance += monthlyDeposit;
            }
            double monthlyInterest = balance * monthlyInterestRate;
            interestEarned += monthlyInterest;
            balance += monthlyInterest;
        }

        cout << year << "\t$" << balance << "\t\t\t$" << interestEarned << endl;
    }
}

// Displays results without monthly deposits
void InvestmentCalculator::DisplayWithoutDeposits() const {
    cout << endl << "Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "===================================================" << endl;
    CalculateBalance(false);
}

// Displays results with monthly deposits
void InvestmentCalculator::DisplayWithDeposits() const {
    cout << endl << "Balance and Interest With Additional Monthly Deposits" << endl;
    cout << "===================================================" << endl;
    CalculateBalance(true);
}
