#include <iostream>
#include <iomanip>
#include "investmentcalculator.h"
using namespace std;

int main() {
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

    // Collect user input
    cout << "**********************************" << endl;
    cout << "********* Data Input *************" << endl;
    cout << "Initial Investment Amount: ";
    cin >> initialInvestment;
    cout << "Monthly Deposit: ";
    cin >> monthlyDeposit;
    cout << "Annual Interest (%): ";
    cin >> annualInterest;
    cout << "Number of years: ";
    cin >> years;

    // Create calculator object
    InvestmentCalculator calc(initialInvestment, monthlyDeposit, annualInterest, years);

    // Display results
    calc.DisplayWithoutDeposits();
    calc.DisplayWithDeposits();

    return 0;
}
