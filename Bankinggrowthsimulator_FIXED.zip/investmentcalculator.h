#ifndef INVESTMENTCALCULATOR_H
#define INVESTMENTCALCULATOR_H

#include <iostream>
#include <iomanip>
using namespace std;

class InvestmentCalculator {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

    // Helper function to calculate monthly balance
    void CalculateBalance(bool includeMonthlyDeposit) const;

public:
    // Constructor
    InvestmentCalculator(double initial, double monthly, double interest, int numYears);

    // Function to print results without monthly deposits
    void DisplayWithoutDeposits() const;

    // Function to print results with monthly deposits
    void DisplayWithDeposits() const;
};

#endif
